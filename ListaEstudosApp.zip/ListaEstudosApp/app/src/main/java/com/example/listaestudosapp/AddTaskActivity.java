package com.example.listaestudosapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddTaskActivity extends AppCompatActivity {

    private EditText editTitulo;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTitulo = findViewById(R.id.editTitulo);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(view -> {
            String titulo = editTitulo.getText().toString().trim();

            if (!titulo.isEmpty()) {
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                String id = db.collection("tarefas").document().getId();

                Estudo novaTarefa = new Estudo(id, titulo, false);
                db.collection("tarefas").document(id).set(novaTarefa)
                        .addOnSuccessListener(aVoid -> finish())
                        .addOnFailureListener(e ->
                                Toast.makeText(this, "Erro ao salvar tarefa", Toast.LENGTH_SHORT).show()
                        );
            } else {
                Toast.makeText(this, "Digite um título!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
