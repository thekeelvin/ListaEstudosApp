package com.example.listaestudosapp;

public class Estudo {
    private String id;
    private String titulo;
    private boolean feito;

    public Estudo() {}

    public Estudo(String id, String titulo, boolean feito) {
        this.id = id;
        this.titulo = titulo;
        this.feito = feito;
    }

    public String getId() { return id; }
    public String getTitulo() { return titulo; }
    public boolean isFeito() { return feito; }

    public void setId(String id) { this.id = id; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setFeito(boolean feito) { this.feito = feito; }
}
