package com.example.listaestudosapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.List;

public class TarefaAdapter extends RecyclerView.Adapter<TarefaAdapter.MyViewHolder> {

    private List<Estudo> lista;
    private Context context;

    public TarefaAdapter(List<Estudo> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CheckBox checkBox = new CheckBox(parent.getContext());
        return new MyViewHolder(checkBox);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Estudo estudo = lista.get(position);
        holder.checkBox.setText(estudo.getTitulo());
        holder.checkBox.setChecked(estudo.isFeito());

        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            estudo.setFeito(isChecked);
            FirebaseFirestore.getInstance()
                    .collection("tarefas")
                    .document(estudo.getId())
                    .set(estudo);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = (CheckBox) itemView;
        }
    }
}
